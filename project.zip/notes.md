
### true values

| file         | result  |
| ------------ | ------- |
| C1065_064    | unsat   |
| C1065_082    | unsat   |
| C140         | sat     |
| C1597_024    | sat     |
| C1597_060    | sat     |
| C1597_081    | sat     |
| C168_128     | unknown |
| C175_145     | sat     |
| C181_3151    | sat     |
| C200_1806    | unsat   |
| C208_120     | unsat   |
| C208_3254    | unknown |
| C210_30      | unknown |
| C210_55      | unsat   |
| C243_188     | unknown |
| C289_179     | unknown |
| C459_4675    | sat     |
| C53_895      | unknown |
| U50_1065_038 | unsat   |
| U50_1065_045 | unsat   |
| U50_4450_035 | sat     |
| U75_1597_024 | sat     |


### submission command

`zip -r project.zip *`