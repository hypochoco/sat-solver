#!/bin/bash

cd src/build
cmake ..
make